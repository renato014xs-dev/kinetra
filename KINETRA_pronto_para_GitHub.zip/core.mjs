/** KINETRA: motor original, determinístico e independente de APIs. */
export const EQUIP = {none:'Sem equipamento',bar:'Barra fixa',parallel:'Paralelas',rope:'Corda',band:'Elásticos',rings:'Argolas',dumbbell:'Halteres',bench:'Banco',gym:'Academia'};
export const GOALS = {strength:'Força',muscle:'Massa muscular',skill:'Habilidades',fitness:'Condicionamento'};
export const LEVELS = {beginner:'Iniciante',intermediate:'Intermediário',advanced:'Avançado'};
// id, nome, padrão, família, grau (1..10), equipamentos obrigatórios alternativos, tipo, técnica, alto risco
const raw = [
['push_wall','Flexão na parede','push','pushup',1,'','rep','Tronco alinhado, flexione cotovelos sem perder o controle.'],
['push_high','Flexão inclinada','push','pushup',2,'','rep','Use apoio muito estável; quanto mais baixo, mais difícil.'],
['push_knee','Flexão com joelhos','push','pushup',3,'','rep','Mantenha quadril e tronco alinhados.'],
['push_regular','Flexão tradicional','push','pushup',4,'','rep','Controle a descida, cotovelos em ângulo confortável.'],
['push_close','Flexão fechada','push','pushup',5,'','rep','Aproxime as mãos sem forçar punhos.'],
['push_decline','Flexão declinada','push','pushup',6,'bench','rep','Pés elevados em apoio estável.'],
['push_archer','Flexão arqueiro','push','pushup',7,'','rep','Desloque o peso de um braço para o outro.'],
['push_one_assist','Flexão unilateral assistida','push','pushup',8,'','rep','Use apoio amplo e estável para diminuir carga.'],
['push_one','Flexão unilateral','push','pushup',10,'','rep','Apenas após domínio da progressão assistida.',true],
['pike_wall','Pike inclinada','push','vertical',2,'','rep','Quadril alto, cabeça em direção ao chão com controle.'],
['pike','Flexão pike','push','vertical',4,'','rep','Tronco inclinado, foco na força de ombro.'],
['pike_elev','Pike com pés elevados','push','vertical',6,'bench','rep','Pés em banco muito firme e sem compensar lombar.'],
['dip_support','Suporte nas paralelas','push','dip',1,'parallel','sec','Ombros estáveis, use os pés para ajudar.'],
['dip_feet','Mergulho assistido nas paralelas','push','dip',3,'parallel','rep','Pés apoiados, amplitude confortável, sem dor.'],
['dip_neg','Mergulho negativo','push','dip',5,'parallel','rep','Desça gradualmente, volte com apoio dos pés.'],
['dip_regular','Mergulho nas paralelas','push','dip',6,'parallel','rep','Tronco controlado, interrompa se houver dor no ombro.'],
['dip_rings','Mergulho nas argolas','push','dip',9,'rings','rep','Exige estabilidade excepcional e acompanhamento.',true],
['row_prone','Remada no chão (contração escapular)','pull','row',1,'','rep','De bruços, aproxime as escápulas sem prender a respiração.'],
['row_ywt','Elevações Y-T-W no chão','pull','row',2,'','rep','Braços estendidos, amplitudes pequenas e controladas.'],
['row_band','Remada com elástico','pull','row',3,'band','rep','Ancore o elástico com segurança e puxe os cotovelos.'],
['row_parallel','Remada australiana inclinada','pull','row',3,'parallel','rep','Pés no chão, mantenha a barra estável e o corpo alinhado.'],
['row_rings','Remada nas argolas','pull','row',4,'rings','rep','Afaste os pés para reduzir inclinação, sem perder alinhamento.'],
['row_horizontal','Remada australiana horizontal','pull','row',5,'parallel','rep','Peito às paralelas, quadril neutro.'],
['row_raised','Remada australiana com pés elevados','pull','row',7,'parallel','rep','Somente com apoios firmes.'],
['hang','Suspensão na barra','pull','pullup',1,'bar','sec','Pendure-se sem soltar ombros bruscamente.'],
['hang_active','Suspensão ativa na barra','pull','pullup',2,'bar','sec','Ative escápulas com braços estendidos.'],
['scap','Retração escapular na barra','pull','pullup',3,'bar','rep','Movimento curto sem dobrar cotovelos.'],
['pull_feet','Barra fixa com apoio dos pés','pull','pullup',3,'bar','rep','Apoio estável permite assistência dos membros inferiores.'],
['pull_band','Barra fixa com elástico','pull','pullup',4,'bar+band','rep','Verifique fixação do elástico antes de cada série.'],
['pull_negative','Barra fixa negativa','pull','pullup',5,'bar','rep','Use apoio para chegar ao topo; desça controladamente.'],
['chinup','Barra supinada','pull','pullup',6,'bar','rep','Sem balanço, mantenha controle do corpo.'],
['pullup','Barra pronada','pull','pullup',7,'bar','rep','Tronco estável e amplitude confortável.'],
['pull_chest','Barra explosiva no peito','pull','pullup',9,'bar','rep','Habilidade avançada; exige experiência e supervisão.',true],
['pull_archer','Barra arqueiro','pull','pullup',10,'bar','rep','Grande assimetria de carga; nível avançado e supervisão.',true],
['squat_chair','Sentar e levantar da cadeira','legs','squat',1,'','rep','Controle a descida e levante sem impulso excessivo.'],
['squat','Agachamento livre','legs','squat',2,'','rep','Pés firmes, joelhos acompanham a direção dos pés.'],
['squat_pause','Agachamento com pausa','legs','squat',3,'','rep','Segure 1-2 s sem perder postura.'],
['lunge_back','Afundo reverso','legs','lunge',3,'','rep','Passo para trás e tronco firme.'],
['lunge_walk','Afundo alternado','legs','lunge',4,'','rep','Alterne pernas e mantenha amplitude confortável.'],
['split_squat','Agachamento dividido','legs','lunge',5,'','rep','Apoio estável de ambas as pernas.'],
['bulgarian','Agachamento búlgaro','legs','lunge',6,'bench','rep','Elevação baixa do pé posterior, equilíbrio primeiro.'],
['pistol_supported','Agachamento unilateral assistido','legs','squat',7,'','rep','Segure num apoio firme, sem colapsar joelho.'],
['pistol','Pistol squat','legs','squat',9,'','rep','Exige mobilidade e força unilateral avançadas.',true],
['bridge','Ponte de glúteos','legs','posterior',1,'','rep','Contraia glúteos no topo, sem arquear lombar.'],
['bridge_hold','Ponte de glúteos com pausa','legs','posterior',2,'','rep','Segure o topo por dois segundos.'],
['bridge_one','Ponte unilateral','legs','posterior',4,'','rep','Mantenha quadril nivelado.'],
['calf','Elevação de panturrilha','legs','calf',2,'','rep','Suba e desça controladamente.'],
['calf_one','Panturrilha unilateral','legs','calf',5,'','rep','Segure apoio para equilíbrio.'],
['plank_knees','Prancha com joelhos','core','plank',1,'','sec','Abdômen ativo, não afunde lombar.'],
['plank','Prancha frontal','core','plank',3,'','sec','Corpo alinhado e respiração natural.'],
['plank_side','Prancha lateral','core','plank',4,'','sec','Quadril elevado e ombro alinhado.'],
['deadbug','Dead bug','core','hollow',1,'','rep','Mantenha contato lombar com o chão.'],
['hollow_tuck','Hollow tuck','core','hollow',3,'','sec','Joelhos agrupados, lombar apoiada.'],
['hollow','Hollow hold','core','hollow',5,'','sec','Braços e pernas afastados só até manter a lombar apoiada.'],
['reverse_crunch','Abdominal reverso','core','raise',2,'','rep','Eleve quadril suavemente sem impulso.'],
['knee_parallel','Elevação de joelhos nas paralelas','core','raise',3,'parallel','rep','Sem balanço, ombros apoiados.'],
['knee_hang','Elevação de joelhos suspenso','core','raise',4,'bar','rep','Sem balanço e sem forçar pegada.'],
['leg_raise','Elevação de pernas na barra','core','raise',7,'bar','rep','Exige estabilidade e controle do quadril.'],
['lsit_tuck','L-sit agrupado','skill','lsit',5,'parallel','sec','Use apoio firme e eleve joelhos em direção ao peito.'],
['lsit','L-sit completo','skill','lsit',8,'parallel','sec','Só após dominar suporte e hollow.'],
['wall_handstand','Parada de mão assistida na parede','skill','handstand',7,'','sec','Somente com espaço seguro, auxílio e saída ensinada.',true],
['front_tuck','Tuck front lever','skill','frontlever',8,'bar','sec','Habilidade avançada; não iniciar sem pré-requisitos e orientação.',true],
['front_adv','Advanced tuck front lever','skill','frontlever',9,'bar','sec','Exige forte controle escapular e acompanhamento.',true],
['front_full','Front lever completo','skill','frontlever',10,'bar','sec','Habilidade profissional, progressão de longo prazo.',true],
['planche_lean','Planche lean','skill','planche',7,'','sec','Aqueça os punhos, avance gradualmente.'],
['planche_tuck','Tuck planche','skill','planche',9,'parallel','sec','Exige preparo específico de punhos e ombros.',true],
['planche','Planche completa','skill','planche',10,'parallel','sec','Habilidade profissional, supervisão recomendada.',true],
['jump_rope','Pular corda','cardio','conditioning',2,'rope','sec','Saltos baixos, volume moderado e atenção ao piso.'],
['march','Marcha acelerada','cardio','conditioning',1,'','sec','Aumente ritmo sem perder a respiração.'],
['jump_jack','Polichinelos','cardio','conditioning',2,'','sec','Aterrisse suavemente.'],
['mountain','Escalador','cardio','conditioning',4,'','sec','Controle o tronco e alterne joelhos.'],
['burpee','Burpee adaptado','cardio','conditioning',5,'','rep','Pode retirar salto e flexão conforme capacidade.'],
['goblet','Agachamento goblet','legs','squat',4,'dumbbell','rep','Carga leve e controle do tronco.'],
['row_dumbbell','Remada com halter','pull','row',4,'dumbbell','rep','Apoio firme, traga o cotovelo para trás.'],
['press_dumbbell','Desenvolvimento de ombro com halteres','push','vertical',4,'dumbbell','rep','Evite compensação lombar.'],
];
export const CATALOG = raw.map(([id,name,pattern,family,difficulty,requirements,unit,cues,highRisk])=>({id,name,pattern,family,difficulty,requirements,unit,cues,highRisk:!!highRisk}));
export const byId = Object.fromEntries(CATALOG.map(x=>[x.id,x]));
export const defaultProfile = {age:'18-29',height:'',weight:'',goal:'muscle',level:'beginner',location:'home',days:2,minutes:45,equipment:['none'],pain:false,consent:false};
export const isMinor = p => p.age === '13-17';
export function hasEquipment(ex, equip=[]) { const r=ex.requirements; return !r || r.split('+').every(x=>equip.includes(x)|| (x==='dumbbell'&&equip.includes('gym'))); }
export function rankDifficulty(profile) {let n={beginner:2,intermediate:5,advanced:7}[profile.level]??2;if(profile.pain)n=Math.min(n,2);if(isMinor(profile))n=Math.min(n,5);return n;}
export function safeCandidates(profile,pattern) {
 return CATALOG.filter(x=>x.pattern===pattern&&hasEquipment(x,profile.equipment)&&(!profile.pain||x.difficulty<=3)&&!x.highRisk);
 // highRisk deliberately excluded from automatic programming: can be explored, not automatically assigned.
}
export function nextAction(id,sessions=[]) {
 const logs=sessions.filter(s=>s.endedAt).flatMap(s=>s.entries.filter(e=>e.id===id).map(e=>({e,s}))).sort((a,b)=>b.s.startedAt.localeCompare(a.s.startedAt));
 if(!logs.length)return 'first';
 const latest=logs[0];if(latest.e.pain||latest.e.technique==='bad'||latest.s.recovery==='poor')return 'reduce';
 const achieved=logs.slice(0,2).every(({e})=>e.technique==='good'&&!e.pain&&e.sets.length>=2&&e.sets.every(v=>v.done&&v.value>=e.target.max&&v.rir>=1));
 return logs.length>=2&&achieved?'advance':'hold';
}
const P={push:['pushup','dip','vertical'],pull:['pullup','row'],legs:['squat','lunge','posterior','calf'],core:['hollow','plank','raise'],cardio:['conditioning'],skill:['lsit','handstand','frontlever','planche']};
function select(pattern,variant,profile,sessions,used) {
 const families=P[pattern]||[];const familyOrder=[...families.slice(variant%families.length),...families.slice(0,variant%families.length)];
 let all=safeCandidates(profile,pattern).filter(x=>!used.has(x.id));
 if(pattern==='skill')all=all.filter(x=>!x.highRisk&&x.difficulty<=rankDifficulty(profile));
 if(!all.length)return null;
 for (const fam of familyOrder){
  const matches=all.filter(x=>x.family===fam).sort((a,b)=>a.difficulty-b.difficulty);
  if(!matches.length)continue;
  const cap=rankDifficulty(profile)+ (variant%2===0?0:1);
  let chosen=matches.filter(x=>x.difficulty<=cap).at(-1)||matches[0];
  const action=nextAction(chosen.id,sessions);
  if(action==='reduce')chosen=matches.find(x=>x.difficulty<chosen.difficulty)||chosen;
  if(action==='advance')chosen=matches.find(x=>x.difficulty>chosen.difficulty&&x.difficulty<=cap+1)||chosen;
  used.add(chosen.id);return chosen;
 }
 const chosen=all.sort((a,b)=>a.difficulty-b.difficulty)[0];used.add(chosen.id);return chosen;
}
export function generateWeek(profile,sessions=[]) {
 const n=Math.min(6,Math.max(2,Number(profile.days)||2));
 // Recovery-oriented schedules. Split uses adjacent days for different emphasis when 4+.
 const days={2:[1,4],3:[1,3,5],4:[1,2,4,5],5:[1,2,3,5,6],6:[1,2,3,4,5,6]}[n];
 const templates={
  2:[['pull','push','legs','core'],['legs','push','pull','core']],
  3:[['pull','push','legs','core'],['legs','pull','push','core'],['push','legs','pull','core']],
  4:[['push','pull','core'],['legs','core'],['pull','push','core'],['legs','core']],
  5:[['push','core'],['pull','core'],['legs','core'],['push','pull'],['legs','core']],
  6:[['push','core'],['pull','core'],['legs','core'],['push','core'],['pull','core'],['legs','core']]
 }[n];
 return days.map((weekday,i)=>{
   const used=new Set(),items=[];
   const groups=[...templates[i]];
   if(profile.goal==='skill'&&profile.level!=='beginner'&&i%2===0) groups.unshift('skill');
   for(const [j,group] of groups.entries()){
    const ex=select(group,i+j,profile,sessions,used);if(!ex)continue;
    const sets=profile.level==='beginner'?2:profile.level==='intermediate'?3:3;
    const unit=ex.unit==='sec';let min=unit?15:6,max=unit?30:12;
    if(group==='legs'&&!unit){min=8;max=15;}
    if(profile.goal==='strength'&&!unit){min=4;max=8;}
    if(profile.goal==='fitness'){min=unit?20:10;max=unit?40:15;}
    const action=nextAction(ex.id,sessions);
    items.push({ex,sets,min,max,rest:profile.goal==='strength'?120:90,action});
   }
   if(profile.equipment.includes('rope')&&(i===0||profile.goal==='fitness')){
     const ex=byId.jump_rope;if(!used.has(ex.id))items.push({ex,sets:2,min:30,max:60,rest:60,action:nextAction(ex.id,sessions)});
   }
   return {id:String.fromCharCode(65+i),weekday,title:n<=3?'Corpo inteiro '+String.fromCharCode(65+i):(['Empurrar + puxar','Pernas + core','Superiores B','Pernas B','Misto'][i]||'Dia '+(i+1)),items};
 });
}
export function makeSession(day) {return {id:(globalThis.crypto?.randomUUID?.()||String(Date.now())+Math.random()),title:day.title,dayId:day.id,startedAt:new Date().toISOString(),endedAt:null,recovery:'good',entries:day.items.map(({ex,sets,min,max,rest})=>({id:ex.id,name:ex.name,unit:ex.unit,target:{sets,min,max,rest},sets:Array.from({length:sets},()=>({value:min,rir:2,done:false})),technique:'good',pain:false}))};}
export function upgradeExercise(ex,sessions,profile){const direction=nextAction(ex.id,sessions);if(direction!=='advance')return null;return CATALOG.filter(x=>x.family===ex.family&&x.difficulty>ex.difficulty&&x.difficulty<=rankDifficulty(profile)+1&&hasEquipment(x,profile.equipment)&&!x.highRisk).sort((a,b)=>a.difficulty-b.difficulty)[0]||null;}
