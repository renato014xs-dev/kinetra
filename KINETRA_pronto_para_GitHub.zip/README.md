# KINETRA 0.1

Aplicativo web progressivo (PWA) de calistenia e treinamento resistido, em português brasileiro, otimizado para celular e com **código próprio sem dependências de build**.

## Recursos já implementados

- Cadastro com faixa etária, altura, peso opcional, objetivo, experiência, duração, local e equipamentos disponíveis.
- Motor local de treino com progressões originais de calistenia, divisão semanal de 2 a 6 dias, recuperação e adaptação conservadora a registros de esforço.
- Catálogo próprio offline com dezenas de variações de movimentos e **integração com a base pública Free Exercise DB, que possui mais de 800 exercícios**. Carregamento da base ocorre via internet na primeira consulta, usando o JSON original da fonte, com cache quando disponível.
- Registro de séries, repetições ou segundos, RIR, técnica, dor relatada, recuperação e histórico de sessões.
- Histórico real de treinos e registro manual de peso e refeições; dados locais exportáveis/importáveis em JSON.
- Bibliografia científica básica, princípios de segurança por faixa etária e aviso contra promessas de hipertrofia em poucos dias.
- PWA instalável, com cache offline do app (após primeiro acesso em HTTPS).

## Funções não implementadas

- Ainda não existe backend, conta, sincronização entre aparelhos, integração nativa com Health Connect, smartwatch ou OKOK.
- Não existe IA remota conectada; o motor usa regras locais testáveis, não respostas simuladas de IA.
- A base externa inclui exercícios com pesos e máquinas. Não é um catálogo exclusivamente de calistenia.
- Não existem demonstrações em vídeo. Instruções da base externa estão no idioma original.
- Uma instalação como PWA não equivale a APK com acesso a sensores nativos.
- Os exemplos de programação são educativos; dor persistente e limitações requerem avaliação profissional.

## Rodar

Por ser um PWA estático, não é necessário instalar dependências.

- Hospede **todos** os arquivos na raiz de um site HTTPS (ex.: GitHub Pages).
- Para desenvolvimento, use um servidor HTTP estático. No computador: `python -m http.server 8080` e acesse `http://localhost:8080`.
- Para testes do motor: `node --test tests/core.test.mjs` (Node.js 20+).
- No Android, abra a URL HTTPS no Chrome e escolha "Adicionar à tela inicial" / "Instalar app", quando disponível.

## Publicar com GitHub Pages

1. Coloque os arquivos na raiz do repositório `kinetra`, sem a pasta que os envolve.
2. Em **Settings > Pages**, selecione a implantação pela branch `main` (raiz `/`) e salve.
3. Abra o endereço GitHub Pages que aparecer depois do deployment.

## Fontes e licenças

- **Free Exercise DB**: [yuhonas/free-exercise-db](https://github.com/yuhonas/free-exercise-db), dataset sob **Unlicense**. O aplicativo faz consulta do JSON público em tempo de uso e não redistribui as imagens. Direitos sobre conteúdos agregados devem ser verificados conforme a origem.
- **ACSM (2026)**: Currier et al., *Resistance Training Prescription for Muscle Function, Hypertrophy, and Physical Performance in Healthy Adults: An Overview of Reviews*. [PMID 41843416](https://pubmed.ncbi.nlm.nih.gov/41843416/). O estudo é sobre adultos saudáveis, não deve ser generalizado como prescrição para crianças.
- **OMS**: [WHO Guidelines on Physical Activity and Sedentary Behaviour](https://www.who.int/publications/i/item/9789240015128).

O motor, a interface, o código e o catálogo de progressões originais podem ser distribuídos sob a licença MIT deste projeto. As licenças das fontes externas permanecem independentes.

## Privacidade

Todos os registros são mantidos no localStorage do navegador; não são enviados para servidor do KINETRA. Não existe backend. O usuário pode exportar seu backup ou apagar tudo. Limpar dados do site apaga o histórico, portanto recomenda-se exportá-lo periodicamente.
